<?php
define('TEMPLATE_DIR', get_stylesheet_directory_uri());
const INC_DIR = TEMPLATE_DIR . '/inc';
const SCRIPT_DIR = TEMPLATE_DIR . '/scripts';
const STYLE_DIR = TEMPLATE_DIR . '/styles';
const ASSET_VERSION = '3.0.0';
const GOOGLE_MAP_API_KEY = 'AIzaSyBw8iEgmYpZs3i8po8HqyXQ1_hPknEo7jc';
